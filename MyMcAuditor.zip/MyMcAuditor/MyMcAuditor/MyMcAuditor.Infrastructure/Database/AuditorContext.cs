﻿using Microsoft.EntityFrameworkCore;
using MyMcClient.Domain.Auditor.ClientEntity;

namespace MyMcClient.Infrastructure.Database
{
    public class AuditorContext : DbContext
    {
        public DbSet<AuditorDataModel> Auditors { get; set; }


        public AuditorContext(DbContextOptions<AuditorContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AuditorDataModel>().ToTable("User");
        }
    }
}
