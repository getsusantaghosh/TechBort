﻿using Microsoft.EntityFrameworkCore;
using MyMcClient.Domain.Auditor;
using MyMcClient.Domain.Auditor.ClientEntity;
using MyMcClient.Infrastructure.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyMcClient.Infrastructure.Client
{
    public class AuditorRepository : IAuditorRepository
    {
        //private readonly ISqlConnectionFactory _sqlConnectionFactory;
        private readonly AuditorContext _context;

        public AuditorRepository(AuditorContext context)
        {
            //this._sqlConnectionFactory = _sqlConnectionFactory;
           this._context = context;

        }

        public async Task<AuditorLoginModel> FindById(string userId)
        {
            var returnInfo = new AuditorLoginModel();
            var user =await this._context.Auditors.FirstOrDefaultAsync(a=>a.UserId==userId);
            if (user != null)
            {
                returnInfo.UserId = user.UserId;
                returnInfo.Password = user.Password;
            }
            return  returnInfo;
        }
        public async Task AddAsync(AuditorDataModel entity)
        {
            try
            {
                //var connection = _sqlConnectionFactory.GetOpenConnection();
                await this._context.Auditors.AddAsync(entity);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
