﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyMcAuditor.Helper.JsonModel
{
  public  class JsonModel
    {
        public string StatusCode { get; set; }
        public string Response { get; set; }
    }
}
