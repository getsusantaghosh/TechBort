﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyMcClient.Helper.Token
{
    public interface ITokenBuilder
    {
        string BuildToken(string username);
    }
}
