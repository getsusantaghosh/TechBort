﻿using MyMcClient.Application.Auditor.Contract;
using MyMcClient.Domain.Auditor;
using MyMcClient.Domain.Auditor.ClientEntity;
using MyMcClient.Helper.Encryption;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MyMcClient.Application.Auditor.Implementation
{
    public class AuditorService : IAuditorService
    {
        private readonly IAuditorRepository _iAuditorRepository;
        public AuditorService(IAuditorRepository iClientRepository)
        {
            this._iAuditorRepository = iClientRepository;
        }
        public async Task<AuditorDataModel> Add(AuditorDataModel auditorInfo)
        {
            try
            {
                //ClientDataModel objClientDataModel = new ClientDataModel();
                //return objClientDataModel;


                string encrytedPassword = Encryption.Encrypt(auditorInfo.Password);

                auditorInfo.Password = encrytedPassword;
                await this._iAuditorRepository.AddAsync(auditorInfo);
                return new AuditorDataModel { Id = auditorInfo.Id };
            }
            catch (Exception ex)
            {

                throw;
            }
        }


        public async Task<Boolean> Authenticate(AuditorLoginModel loginInfo)
        {
            try
            {
                //ClientDataModel objClientDataModel = new ClientDataModel();
                //return objClientDataModel;

                var isAuthenticate = false;
                string encrytedPassword = Encryption.Encrypt(loginInfo.Password);
     


                var userInfo = await this._iAuditorRepository.FindById(loginInfo.UserId);         

                isAuthenticate = userInfo != null && loginInfo.Password == Encryption.Decrypt(userInfo.Password) ? true : false;
                return isAuthenticate;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
