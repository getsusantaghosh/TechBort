﻿using MyMcClient.Domain.Auditor.ClientEntity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace MyMcClient.Application.Auditor.Contract
{
    public interface IAuditorService
    {
        public Task<AuditorDataModel> Add(AuditorDataModel clientInfo);
        public Task<Boolean> Authenticate(AuditorLoginModel loginInfo);
    }
}
