﻿using Microsoft.AspNetCore.Mvc;
using MyMcAuditor.Helper.JsonModel;
using MyMcClient.Application.Auditor.Contract;
using MyMcClient.Domain.Auditor.ClientEntity;
using MyMcClient.Helper.Token;
using System;
using System.Threading.Tasks;

namespace MyMcClient.Controllers
{
    //[Route("api/[controller]/[action]")]
    //[Route("[controller]")]

    [ApiController]
    //[Route("api/ClientInfo")]
    [Route("api/[controller]/[action]")]
    public class AuditInfoController : ControllerBase
    {
        private readonly IAuditorService _iAuditorService;
        private readonly ITokenBuilder _tokenBuilder;
        public AuditInfoController(IAuditorService iAuditorService, ITokenBuilder tokenBuilder)
        {
            this._iAuditorService = iAuditorService;
            _tokenBuilder = tokenBuilder;
        }

        [HttpPost]
        public async Task<JsonResult> RegisterNewAuditor(AuditorDataModel auditorInfo)
        {
            var response = new JsonModel();
            try
            {
                int isSuccess = 0;
           
              var  oModel = await _iAuditorService.Add(auditorInfo);


                if (oModel!=null)
                {
                  
                    response.StatusCode="200";
                    response.Response = "Auditor Created successfully";
                    
                }
            }
            catch (Exception ex)
            {

                response.StatusCode = "400";
                response.Response = "Failed to create an Auditor";
            }
            return new JsonResult(response);
        }


        // GET: api/<ValuesController>
        [HttpGet]
        public async Task<JsonResult> Authenticate(AuditorLoginModel loginInfo)
        {

            var response = new JsonModel();

            var isAuthenticated = await _iAuditorService.Authenticate(loginInfo); 

                if (!isAuthenticated)
                {
                response.StatusCode = "400";
                response.Response = "Authentication Failed";
            }
                else
            {
                var token = _tokenBuilder.BuildToken(loginInfo.UserId);
                response.StatusCode = "200";
                response.Response = token;
            }

            return new JsonResult(response);
            
        }

            [HttpGet]
        public string InfoDetails(int id)
        {
            return id.ToString();
        }
    }
}