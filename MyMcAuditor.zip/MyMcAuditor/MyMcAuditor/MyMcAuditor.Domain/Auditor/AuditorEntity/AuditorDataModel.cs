﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyMcClient.Domain.Auditor.ClientEntity
{
    //[DatabaseGenerated(DatabaseGeneratedOption.None)]
    public class AuditorDataModel
    {
        public virtual int? Id { get; set; }
        public virtual string UserId { get;  set; }

        public virtual string FirstName { get;  set; }
        public virtual string LastName { get;  set; }
        public virtual string Email { get;  set; }
        public virtual string Password { get;  set; }

        public virtual string Address { get;  set; }


        public virtual string Phone { get;  set; }
    }

    public class AuditorLoginModel
    {
    
        public virtual string UserId { get; set; }

        public virtual string Password { get; set; }
   
    }
}
