﻿using MyMcClient.Domain.Auditor.ClientEntity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MyMcClient.Domain.Auditor
{
    public interface IAuditorRepository //<TEntity>
    {
        /*TEntity FindById(int id);
        TEntity FindOne(ISpecification<TEntity> spec);
        IEnumerable<TEntity> Find(ISpecification<TEntity> spec);
        void Add(TEntity entity);
        void Remove(TEntity entity);*/

        //Task<ClientDataModel> GetAsync(String Id);
        Task AddAsync(AuditorDataModel entity);
        Task<AuditorLoginModel> FindById(string id);
        //Task EditAsync(ClientDataModel entity);

    }
}
